<?
$MESS ['MAIN_FEEDBACK_COMPONENT_NAME'] = "My Feedback Form";
$MESS ['MAIN_FEEDBACK_COMPONENT_DESCR'] = "Feedback form send email";
?>