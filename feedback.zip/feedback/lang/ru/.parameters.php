<?
$MESS ['MFP_CAPTCHA'] = "Использовать защиту от автоматических сообщений (CAPTCHA) для неавторизованных пользователей";
$MESS ['MFP_OK_MESSAGE'] = "Сообщение, выводимое пользователю после отправки";
$MESS ['MFP_OK_TEXT'] = "Спасибо, ваше сообщение принято.";
$MESS ['MFP_EMAIL_TO'] = "E-mail, на который будет отправлено письмо";
$MESS ['MFP_REQUIRED_FIELDS'] = "Обязательные поля для заполнения";
$MESS ['MFP_ALL_REQ'] = "(все необязательные)";
$MESS ['MFP_NAME'] = "Имя";
$MESS ['MFP_PHONE'] = "Телефон";
$MESS ['MFP_EMAIL'] = "EMail";
$MESS ['MFP_MESSAGE'] = "Сообщение";
$MESS ['MFP_EMAIL_TEMPLATES'] = "Почтовые шаблоны для отправки письма";
?>