<?
$MESS ['MFT_NAME'] = "Ваше имя";
$MESS ['MFT_EMAIL'] = "Ваш E-mail";
$MESS ['MFT_PHONE'] = "Ваш телефон";
$MESS ['MFT_SUBMIT'] = "Отправить";
?>